<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Document</title>

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>

<style>
	/* mas estilisado */	
		body{
			background-color: #f0f0f0  !important;
		}
</style>
<body>
	<div class="col-12" style="height: 60px; background: white; box-shadow: 1px 1px 10px rgba(0, 0, 0, 0.158);">

	</div>

	<div class="col-12 mt-5">
		<div class="container d-flex justify-content-center aling-items-start">
			<div class="card mx-2" style="width: 260px; height: 600px; border-radius:16px; box-shadow: 1px 1px 5px rgba(0, 0, 0, 0.089);"></div>

			<div class="card mx-2" style="width: 825px; height: 600px; border-radius:16px; box-shadow: 1px 1px 5px rgba(0, 0, 0, 0.089);"></div>
		</div>
	</div>
</body>
</html>
