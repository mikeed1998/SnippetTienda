@extends('layouts.front')

@section('cssExtras')
@endsection
@section('styleExtras')
@endsection
@section('content')
@endsection

@section('jsLibExtras2')
@endsection
